<?php

require __DIR__.'/vendor/autoload.php';

use \App\Validation\CPF;

$resultado = CPF::validar("277.823.850-67");

var_dump($resultado);