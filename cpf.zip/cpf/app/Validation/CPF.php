<?php

namespace App\Validation;

class CPF{
    /**
     * Método responsável por verificar se um CPF é realmente válido
     * [validar description]
     * @param string [type] $cpf
     * @return boolean [type]
     */
    public static function validar($cpf){
        //OBTÉM SOMENTE OS NÚMEROS
        $cpf = preg_replace('/\D/','',$cpf);

        //VERIFICA A QUANTIDADE DE CARACTERES
        if(strlen($cpf) != 11){
            return false;
        }
    
        //DIGITO VERIFICADOR
        $cpfValidacao = substr($cpf,0,9);
        $cpfValidacao.= self::calcularDigitoVerificador($cpfValidacao);
        $cpfValidacao.= self::calcularDigitoVerificador($cpfValidacao);

        //COMPARA O CPF CALCULADO COM O VALIDADO
        return $cpfValidacao == $cpf;
    }

    /**
     * Método responsável por calcular um dígito verificador com base em uma sequência numérica
     * @param string[type] $base
     * @return string[type]
     */
    public static function calcularDigitoVerificador($base){
        //AUXILIARES
        $tamanho = strlen($base);
        $multiplicador = $tamanho + 1;

        //SOMA
        $soma = 0;

        //ITERA OS NÙMEROS DO CPF
        for($i = 0; $i < $tamanho; $i++){
            $soma += $base[$i] * $multiplicador;
            $multiplicador--;
        }

        //RESTO DA DIVISÂO
        $resto = $soma % 11;

        //RETORNA O DÌGITO VERIFICADOR
        return $resto > 1 ? 11 - $resto : 0;

    }

}